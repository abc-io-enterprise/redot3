const express = require('express');
const app = express();
const port = Number(process.env.PORT || 4000);

app.get('/', (req, res) => {
  res.json({ status: 'gateway', message: 'ABC-IO v2.0 API gateway online.' });
});

app.get('/health', (req, res) => {
  res.json({ status: 'ok' });
});

app.listen(port, () => {
  console.log(`Gateway listening on port ${port}`);
});
