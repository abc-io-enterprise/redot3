# Security Framework

## Access Control

- Services use environment variables for secrets.
- Gateway enforces TLS termination through `nginx`.
- API authentication is expected on the gateway layer.

## Hardening

- Production compose uses non-root containers.
- Logging is restricted to secure volumes.
- Monitoring and alerting are configured via Prometheus.

## Secrets

- Do not commit `.env`.
- Use external secret management in production when possible.
