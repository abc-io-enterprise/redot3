from flask import Flask, jsonify, request

app = Flask(__name__)

@app.route('/')
def root():
    return jsonify({
        'service': 'kimi',
        'status': 'online',
        'model': request.environ.get('MODEL', 'default')
    })

@app.route('/health')
def health():
    return jsonify({'status': 'ok'})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
