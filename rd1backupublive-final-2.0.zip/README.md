# ABC-IO v2.0

## Overview

ABC-IO v2.0 is a containerized system package for local development, production deployment, and release packaging.

## Quick Start (Local Development)

```bash
cd redot2
docker compose up -d
sleep 20
./scripts/health-check.sh
```

## Local Validation

- API gateway health: `http://localhost:4000/health`
- Operator Station UI: `http://localhost:8080/`
- Kimi service health: `http://localhost:5000/health`
- Prometheus: `http://localhost:9090`
- Grafana: `http://localhost:3000`
- Jaeger UI: `http://localhost:16686`

## Release Packaging

To create a packaged ZIP archive for distribution, run:

```powershell
./scripts/package-release.ps1
```

## Production Deployment

Before production deployment:

1. Copy `.env.example` to `.env`.
2. Set `POSTGRES_PASSWORD` in `.env`.
3. Review `DEPLOYMENT.md` for VPS provisioning and live rollout.
4. Use `docker compose -f compose.prod.yml up -d`.

## Project structure

- `docker-compose.yml` — primary 10-service orchestration.
- `compose.dev.yml` — developer environment.
- `compose.prod.yml` — production environment.
- `config/` — NGINX and Prometheus configuration.
- `services/` — gateway, dashboard, AI service, and DB schema.
- `scripts/` — release and operations automation.
- `.github/workflows/` — CI and release automation templates.

## Notes

- This environment cannot publish to GitHub or Namecheap automatically without user credentials.
- Use `README.md` and `DEPLOYMENT.md` together when moving to production.
